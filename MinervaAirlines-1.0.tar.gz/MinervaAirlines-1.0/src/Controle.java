public interface Controle {
	
	public void direcionar_aviao(String destino);
	public void aumentar_velocidade(double velocidade);
}
