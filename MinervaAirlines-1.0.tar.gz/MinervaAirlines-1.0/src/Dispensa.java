
public interface Dispensa {

	public void ver_items();
	public void reabastecer_dispensa();
}
