
public interface Comunicacao {
	
	public void comunica_torre(int caso);
}
