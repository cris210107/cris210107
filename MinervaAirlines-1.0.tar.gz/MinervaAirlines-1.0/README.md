![SanchaCppParser](https://github.com/danielbispov/MinervaAirlines/blob/master/img/airline.png?raw=true)
## Bem Vindo(a) ao MinervaAirlines

O __MinervaAirlines__ é uma abstração de uma forma de organização de pessoas dentro de um avião e os seus respectivos privilégios dentro dele.

#### Equipe

* [Allex Lima](http://allexlima.com)
* [Daniel Bispo](https://github.com/danielbispov/)
* [Paulo Moraes](http://pauloigormoraes.com/)
* [Renan Barroncas](https://github.com/renanbarroncas)

###### Copyright © 2016 [MinervaAirlines](https://github.com/danielbispov/MinervaAirlines)  - Licensed by MIT LICENSE.
