.. _background:

===============
About Briefcase
===============

.. toctree::
   :maxdepth: 1
   :glob:

   faq
   community
   success
   releases
