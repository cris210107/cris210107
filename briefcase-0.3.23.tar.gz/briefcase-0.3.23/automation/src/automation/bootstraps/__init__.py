BRIEFCASE_EXIT_SUCCESS_SIGNAL = ">>>>>>>>>> EXIT 0 <<<<<<<<<<"
EXIT_SUCCESS_NOTIFY = ">>> successfully started...exiting <<<"
